package com.frostpunk.block;

import com.frostpunk.util.LuckPermsUtil;
import com.mojang.serialization.MapCodec;
import net.minecraft.block.*;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3908;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import com.frostpunk.block.ModBlockEntities;

public class ControlPanelBlock extends class_2237 {
    public static final MapCodec<ControlPanelBlock> CODEC = method_54094(ControlPanelBlock::new);

    public ControlPanelBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    protected MapCodec<? extends class_2237> method_53969() {
        return field_46280;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return ModBlockEntities.CONTROL_PANEL_ENTITY.method_11032(pos, state);
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit) {
        if (!world.field_9236) {
            // Проверка роли инженера через LuckPerms
            if (!LuckPermsUtil.hasEngineerRole(player)) {
                player.method_7353(class_2561.method_43470("§c[GENERATOR] §7Только §6Инженер §7может управлять генератором."), true);
                return class_1269.field_5814;
            }

            class_2586 be = world.method_8321(pos);
            if (be instanceof class_3908 factory) {
                player.method_17355(factory);
            }
        }
        return class_1269.field_5812;
    }

    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return method_31618(type, ModBlockEntities.CONTROL_PANEL_ENTITY, (w, p, s, be) -> {
            // Сюда можно вписать логику тиков, если Claude добавил метод tick
        });
    }

    @Override
    protected class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }
}
