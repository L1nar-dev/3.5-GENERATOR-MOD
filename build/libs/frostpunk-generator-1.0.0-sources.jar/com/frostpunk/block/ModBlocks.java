package com.frostpunk.block;

import com.frostpunk.FrostpunkMod;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_4970;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public class ModBlocks {

    public static final ControlPanelBlock CONTROL_PANEL = new ControlPanelBlock(
        class_4970.class_2251.method_9637()
            .method_9629(5.0f, 1200.0f)
            .method_9626(class_2498.field_11533)
            .method_22488()
    );

    public static void register() {
        registerBlock("control_panel", CONTROL_PANEL);

        // Add to tools/utilities creative tab
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40197).register(entries -> {
            entries.method_45421(CONTROL_PANEL);
        });

        FrostpunkMod.LOGGER.info("Blocks registered.");
    }

    private static void registerBlock(String name, class_2248 block) {
        class_2960 id = class_2960.method_60655(FrostpunkMod.MOD_ID, name);
        class_2378.method_10230(class_7923.field_41175, id, block);
        class_2378.method_10230(class_7923.field_41178, id,
            new class_1747(block, new class_1792.class_1793()));
    }
}
