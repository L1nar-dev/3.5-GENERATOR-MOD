package com.frostpunk.block;

import com.frostpunk.FrostpunkMod;
import com.frostpunk.screen.GeneratorScreenHandler;
import com.frostpunk.util.ColdSweatUtil;
import com.frostpunk.util.GeneratorEventLog;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_7225;
import java.util.Random;

public class ControlPanelBlockEntity extends class_2586 implements ExtendedScreenHandlerFactory {

    // Power levels 1-4
    private int powerLevel = 1;
    // Radius levels 1-4
    private int radiusLevel = 1;
    // Is boost unlocked by operator
    private boolean boostUnlocked = false;
    // Is boost currently active
    private boolean boostActive = false;
    // Boost overload 0-100
    private int overloadPercent = 0;
    // Is generator broken
    private boolean broken = false;
    // Is generator running
    private boolean running = false;
    // Outside temperature in Celsius (set by command)
    private int outsideTemp = -10;
    // Coal inventory (1 slot)
    private final class_1277 coalInventory = new class_1277(1);
    // Ticks counter
    private int tickCounter = 0;
    // Random for failures
    private final Random random = new Random();
    // Coal consumption ticks (20 sec = 400 ticks)
    private static final int COAL_TICK_INTERVAL = 400;
    // Overload increase per second when boost active
    private static final int OVERLOAD_PER_SECOND = 1; // 100 seconds to explode

    // Coal per minute per power level
    public static final int[] COAL_PER_MIN = {0, 1, 2, 4, 7};
    // Coal consumed per interval (every 20 sec = 1/3 of per-minute)
    // We consume every 20 ticks*20 = 400 ticks, so per interval = perMin / 3
    // Actually we just tick every 400 ticks and consume perMin/3, rounded

    // Radius in blocks per level
    public static final int[] RADIUS_BLOCKS = {0, 30, 45, 65, 100};

    // Heat zone thresholds (Celsius)
    // comfortable >= -5, acceptable >= -15, cool >= -25, cold >= -35, very cold >= -45, freezing < -45
    public static final int[] HEAT_THRESHOLDS = {-5, -15, -25, -35, -45};

    public ControlPanelBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.CONTROL_PANEL_ENTITY, pos, state);
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, ControlPanelBlockEntity be) {
        if (world.field_9236) return;
        be.tickCounter++;

        // Random breakdown when boost is locked (generator in bad condition)
        if (!be.boostUnlocked && !be.broken && be.running) {
            // ~0.5% chance per second (every 20 ticks)
            if (be.tickCounter % 20 == 0 && be.random.nextInt(200) == 0) {
                be.triggerBreakdown(world);
            }
        }

        // Boost overload
        if (be.boostActive && !be.broken && be.running) {
            if (be.tickCounter % 20 == 0) {
                be.overloadPercent += OVERLOAD_PER_SECOND;
                if (be.overloadPercent >= 100) {
                    be.triggerExplosion(world, pos);
                    return;
                }
                be.method_5431();
                be.sync();
            }
        }

        // Coal consumption every 400 ticks (20 sec)
        if (be.tickCounter % COAL_TICK_INTERVAL == 0) {
            if (!be.broken) {
                be.consumeCoal(world, pos);
            }
        }

        // Snow melting in radius every 5 seconds
        if (be.tickCounter % 100 == 0 && be.running && !be.broken) {
            be.meltSnowInRadius(world, pos);
        }

        // Update Cold Sweat temperature every 5 seconds
        if (be.tickCounter % 100 == 0) {
            ColdSweatUtil.updateZoneTemperature(world, pos,
                be.running && !be.broken ? be.radiusLevel : 0,
                be.outsideTemp, be.powerLevel, be.boostActive);
        }
    }

    private void consumeCoal(class_1937 world, class_2338 pos) {
        if (!running) return;

        int coalNeeded = getCoalPerInterval();
        class_1799 stack = coalInventory.method_5438(0);

        if (stack.method_7960() || stack.method_7947() < coalNeeded) {
            // Not enough coal - shutdown
            running = false;
            broadcastMessage(world, "§c[ГЕНЕРАТОР] §7Уголь закончился! Генератор отключается...");
            method_5431();
            sync();
            return;
        }

        stack.method_7934(coalNeeded);
        if (stack.method_7960()) coalInventory.method_5447(0, class_1799.field_8037);

        // Warn when low
        int remaining = coalInventory.method_5438(0).method_7947();
        if (remaining <= 8) {
            broadcastMessage(world, "§e[ГЕНЕРАТОР] §7Уголь на исходе! Осталось: §c" + remaining + " §7ед.");
        }

        method_5431();
        sync();
    }

    private int getCoalPerInterval() {
        // Every 20 sec = 1/3 of per-minute consumption
        int perMin = COAL_PER_MIN[powerLevel];
        int boost = boostActive ? 5 : 0;
        // 3 intervals per minute, round up
        return Math.max(1, (int) Math.ceil((perMin + boost) / 3.0));
    }

    private void triggerBreakdown(class_1937 world) {
        broken = true;
        running = false;
        broadcastMessage(world, "§c[ГЕНЕРАТОР] §7⚠ Генератор сломался! Требуется ремонт.");
        GeneratorEventLog.log("BREAKDOWN", "Generator broke down spontaneously");
        method_5431();
        sync();
    }

    private void triggerExplosion(class_1937 world, class_2338 pos) {
        overloadPercent = 100;
        broken = true;
        running = false;
        boostActive = false;
        broadcastMessage(world, "§4[ГЕНЕРАТОР] §c☠ ПЕРЕГРУЗКА! ГЕНЕРАТОР ВЗОРВАЛСЯ!");
        GeneratorEventLog.log("EXPLOSION", "Generator exploded from overdrive overload");
        world.method_8437(null, pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5,
            3.5f, class_1937.class_7867.field_40889);
        method_5431();
        sync();
    }

    private void meltSnowInRadius(class_1937 world, class_2338 pos) {
        int radius = RADIUS_BLOCKS[radiusLevel];
        // Only melt snow within current radius, check a sample of blocks for performance
        for (int i = 0; i < 10; i++) {
            int dx = random.nextInt(radius * 2) - radius;
            int dz = random.nextInt(radius * 2) - radius;
            double dist = Math.sqrt(dx * dx + dz * dz);
            if (dist > radius) continue;

            class_2338 checkPos = pos.method_10069(dx, 0, dz);
            // Check a few Y levels
            for (int dy = -3; dy <= 3; dy++) {
                class_2338 snowPos = checkPos.method_10069(0, dy, 0);
                class_2680 snowState = world.method_8320(snowPos);
                if (snowState.method_27852(class_2246.field_10477) || snowState.method_27852(class_2246.field_10491)) {
                    world.method_8501(snowPos, class_2246.field_10124.method_9564());
                }
            }
        }
    }

    private void broadcastMessage(class_1937 world, String message) {
        if (world.method_8503() == null) return;
        world.method_8503().method_3760().method_43514(class_2561.method_43470(message), false);
    }

    // === Actions called from screen handler ===

    public void setPowerLevel(int level, class_3222 player) {
        if (broken) {
            player.method_7353(class_2561.method_43470("§c[ГЕНЕРАТОР] §7Генератор сломан!"), true);
            return;
        }
        if (level < 1 || level > 4) return;
        this.powerLevel = level;
        this.running = true;
        GeneratorEventLog.log("POWER", player.method_5477().getString() + " set power to level " + level);
        method_5431();
        sync();
    }

    public void setRadiusLevel(int level, class_3222 player) {
        if (level < 1 || level > 4) return;
        this.radiusLevel = level;
        GeneratorEventLog.log("RADIUS", player.method_5477().getString() + " set radius to level " + level + " (" + RADIUS_BLOCKS[level] + " blocks)");
        method_5431();
        sync();
    }

    public void setBoostActive(boolean active, class_3222 player) {
        if (!boostUnlocked) {
            player.method_7353(class_2561.method_43470("§c[ГЕНЕРАТОР] §7Форсаж заблокирован!"), true);
            return;
        }
        if (broken) {
            player.method_7353(class_2561.method_43470("§c[ГЕНЕРАТОР] §7Генератор сломан!"), true);
            return;
        }
        this.boostActive = active;
        GeneratorEventLog.log("BOOST", player.method_5477().getString() + (active ? " activated" : " deactivated") + " overdrive");
        if (active) {
            broadcastMessage(player.method_37908(), "§c[ГЕНЕРАТОР] §7⚡ Форсаж активирован! Следите за перегрузкой!");
        }
        method_5431();
        sync();
    }

    // === Operator commands ===

    public void unlockBoost() {
        boostUnlocked = true;
        overloadPercent = 0;
        GeneratorEventLog.log("SYSTEM", "Overdrive unlocked by operator");
        method_5431();
        sync();
    }

    public void lockBoost() {
        boostUnlocked = false;
        boostActive = false;
        GeneratorEventLog.log("SYSTEM", "Overdrive locked by operator");
        method_5431();
        sync();
    }

    public void repair() {
        broken = false;
        overloadPercent = 0;
        boostActive = false;
        GeneratorEventLog.log("SYSTEM", "Generator repaired by operator");
        method_5431();
        sync();
    }

    public void setOutsideTemp(int celsius) {
        this.outsideTemp = celsius;
        GeneratorEventLog.log("TEMP", "Outside temperature set to " + celsius + "°C");
        method_5431();
        sync();
    }

    // === Getters ===

    public int getPowerLevel() { return powerLevel; }
    public int getRadiusLevel() { return radiusLevel; }
    public boolean isBoostUnlocked() { return boostUnlocked; }
    public boolean isBoostActive() { return boostActive; }
    public int getOverloadPercent() { return overloadPercent; }
    public boolean isBroken() { return broken; }
    public boolean isRunning() { return running; }
    public int getOutsideTemp() { return outsideTemp; }
    public class_1277 getCoalInventory() { return coalInventory; }

    public int getHeatZone() {
        if (!running || broken) return 6; // freezing
        int temp = outsideTemp;
        // Each power level adds effective warmth
        int effectiveTemp = temp + (powerLevel * 8) + (boostActive ? 12 : 0);
        if (effectiveTemp >= -5) return 1;   // comfortable
        if (effectiveTemp >= -15) return 2;  // acceptable
        if (effectiveTemp >= -25) return 3;  // cool
        if (effectiveTemp >= -35) return 4;  // cold
        if (effectiveTemp >= -45) return 5;  // very cold
        return 6;                            // freezing
    }

    public int getCoalCount() {
        return coalInventory.method_5438(0).method_7947();
    }

    public int getMinutesOfCoalLeft() {
        int perMin = COAL_PER_MIN[powerLevel] + (boostActive ? 5 : 0);
        if (perMin == 0) return 999;
        return getCoalCount() / perMin;
    }

    // === NBT ===

    @Override
    protected void method_11007(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11007(nbt, registries);
        nbt.method_10569("PowerLevel", powerLevel);
        nbt.method_10569("RadiusLevel", radiusLevel);
        nbt.method_10556("BoostUnlocked", boostUnlocked);
        nbt.method_10556("BoostActive", boostActive);
        nbt.method_10569("OverloadPercent", overloadPercent);
        nbt.method_10556("Broken", broken);
        nbt.method_10556("Running", running);
        nbt.method_10569("OutsideTemp", outsideTemp);
        class_2487 coalNbt = new class_2487();
        coalNbt.method_10566("Stack", coalInventory.method_5438(0).method_57358(registries));
        nbt.method_10566("Coal", coalNbt);
    }

    @Override
    protected void method_11014(class_2487 nbt, class_7225.class_7874 registries) {
        super.method_11014(nbt, registries);
        powerLevel = nbt.method_10550("PowerLevel");
        radiusLevel = nbt.method_10550("RadiusLevel");
        boostUnlocked = nbt.method_10577("BoostUnlocked");
        boostActive = nbt.method_10577("BoostActive");
        overloadPercent = nbt.method_10550("OverloadPercent");
        broken = nbt.method_10577("Broken");
        running = nbt.method_10577("Running");
        outsideTemp = nbt.method_10550("OutsideTemp");
        if (nbt.method_10545("Coal")) {
            class_2487 coalNbt = nbt.method_10562("Coal");
            coalInventory.method_5447(0, class_1799.method_57360(registries, coalNbt.method_10562("Stack")).orElse(class_1799.field_8037));
        }
    }

    // === Sync ===

    public void sync() {
        if (field_11863 != null && !field_11863.field_9236) {
            field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        }
    }

    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registries) {
        return method_38244(registries);
    }

    // === Screen handler factory ===

    @Override
    public class_1703 createMenu(int syncId, class_1661 playerInventory, class_1657 player) {
        return new GeneratorScreenHandler(syncId, playerInventory, this);
    }

    @Override
    public class_2561 method_5476() {
        return class_2561.method_43470("Generator Control Panel");
    }

    @Override
    public GeneratorScreenHandler.SyncData getScreenOpeningData(class_3222 player) {
        return new GeneratorScreenHandler.SyncData(field_11867);
    }
}
