package com.frostpunk.block;

import com.frostpunk.FrostpunkMod;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModBlockEntities {

    public static class_2591<ControlPanelBlockEntity> CONTROL_PANEL_ENTITY;

    public static void register() {
        CONTROL_PANEL_ENTITY = class_2378.method_10230(
            class_7923.field_41181,
            class_2960.method_60655(FrostpunkMod.MOD_ID, "control_panel"),
            FabricBlockEntityTypeBuilder.create(ControlPanelBlockEntity::new, ModBlocks.CONTROL_PANEL).build()
        );
        FrostpunkMod.LOGGER.info("Block entities registered.");
    }
}
