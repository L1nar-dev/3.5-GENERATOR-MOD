package com.frostpunk.screen;

import com.frostpunk.FrostpunkMod;
import com.frostpunk.network.ModPackets;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_465;

public class GeneratorScreen extends class_465<GeneratorScreenHandler> {

    private static final class_2960 TEXTURE = class_2960.method_60655(FrostpunkMod.MOD_ID, "textures/gui/generator.png");
    private static final class_2960 GENERATOR_IMG = class_2960.method_60655(FrostpunkMod.MOD_ID, "textures/gui/generator_image.png");

    // GUI size
    private static final int GUI_WIDTH = 256;
    private static final int GUI_HEIGHT = 256;

    // Heat zone colors
    private static final int[] HEAT_COLORS = {
        0, // index 0 unused
        0xFFCC2200, // 1 - comfortable - red
        0xFFCC8800, // 2 - acceptable - yellow
        0xFF2288CC, // 3 - cool - light blue
        0xFF0044CC, // 4 - cold - blue
        0xFF001888, // 5 - very cold - dark blue
        0xFF440088  // 6 - freezing - purple
    };

    private static final String[] HEAT_ZONE_NAMES = {
        "", "КОМФОРТНО", "ПРИЕМЛЕМО", "ПРОХЛАДНО", "ХОЛОДНО", "ОЧ.ХОЛОДНО", "МОРОЗНО"
    };

    public GeneratorScreen(GeneratorScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
        this.field_2792 = GUI_WIDTH;
        this.field_2779 = GUI_HEIGHT;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        this.field_25267 = 999; // hide default title
        this.field_25269 = 999;

        int x = (this.field_22789 - GUI_WIDTH) / 2;
        int y = (this.field_22790 - GUI_HEIGHT) / 2;

        // Power level buttons
        for (int i = 1; i <= 4; i++) {
            final int level = i;
            String label = switch (i) {
                case 1 -> "I  MIN";
                case 2 -> "II STD";
                case 3 -> "III HIGH";
                case 4 -> "IV MAX";
                default -> "";
            };
            this.method_37063(class_4185.method_46430(class_2561.method_43470(label), btn -> {
                ModPackets.sendSetPower(level);
            }).method_46434(x + 140 + ((i - 1) % 2) * 52, y + 60 + ((i - 1) / 2) * 22, 50, 20).method_46431());
        }

        // Boost button
        this.method_37063(class_4185.method_46430(class_2561.method_43470("⚡ OVERDRIVE"), btn -> {
            ModPackets.sendToggleBoost();
        }).method_46434(x + 140, y + 106, 104, 18).method_46431());

        // Radius buttons
        for (int i = 1; i <= 4; i++) {
            final int level = i;
            this.method_37063(class_4185.method_46430(class_2561.method_43470("R" + i), btn -> {
                ModPackets.sendSetRadius(level);
            }).method_46434(x + 140 + (i - 1) * 26, y + 175, 24, 14).method_46431());
        }
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        int x = (this.field_22789 - GUI_WIDTH) / 2;
        int y = (this.field_22790 - GUI_HEIGHT) / 2;

        // Dark background
        context.method_25294(x, y, x + GUI_WIDTH, y + GUI_HEIGHT, 0xFF1A1410);
        // Border
        context.method_25294(x, y, x + GUI_WIDTH, y + 2, 0xFF5A4020);
        context.method_25294(x, y + GUI_HEIGHT - 2, x + GUI_WIDTH, y + GUI_HEIGHT, 0xFF2A1A08);
        context.method_25294(x, y, x + 2, y + GUI_HEIGHT, 0xFF5A4020);
        context.method_25294(x + GUI_WIDTH - 2, y, x + GUI_WIDTH, y + GUI_HEIGHT, 0xFF2A1A08);

        // Title bar
        context.method_25294(x, y, x + GUI_WIDTH, y + 18, 0xFF2A1E10);
        context.method_25294(x, y + 18, x + GUI_WIDTH, y + 20, 0xFF5A4020);
        context.method_51433(this.field_22793, "⚙ GENERATOR CONTROL PANEL", x + 8, y + 5, 0xFFD4A855, false);

        // Status dot (blinking)
        long time = System.currentTimeMillis();
        boolean blink = (time % 2000) > 1000;
        context.method_25294(x + GUI_WIDTH - 14, y + 7, x + GUI_WIDTH - 8, y + 13,
            blink ? 0xFFFF4400 : 0xFF441100);

        // Left panel - generator image background
        context.method_25294(x + 2, y + 20, x + 132, y + GUI_HEIGHT - 2, 0xFF0F0C08);

        // Try to draw generator image
        try {
            context.method_25290(GENERATOR_IMG, x + 2, y + 20, 0, 0, 130, GUI_HEIGHT - 22, 130, GUI_HEIGHT - 22);
        } catch (Exception e) {
            // Draw placeholder if image not found
            context.method_51433(this.field_22793, "⚙", x + 55, y + 100, 0x335A4030, false);
            context.method_51433(this.field_22793, "GENERATOR", x + 30, y + 130, 0x225A4030, false);
        }

        // Gradient overlay on image
        for (int i = 0; i < 30; i++) {
            int alpha = (int)(255 * (i / 30.0f));
            context.method_25294(x + 102 + i, y + 20, x + 103 + i, y + GUI_HEIGHT - 2,
                (alpha << 24) | 0x1A1410);
        }

        // Status badge on image
        context.method_25294(x + 4, y + GUI_HEIGHT - 30, x + 130, y + GUI_HEIGHT - 4, 0xCC0A0804);
        context.method_25294(x + 4, y + GUI_HEIGHT - 30, x + 130, y + GUI_HEIGHT - 28, 0xFF5A4020);
        String statusText = field_2797.isBroken() ? "§cBROKEN" : field_2797.isRunning() ? "§aACTIVE · LVL " + field_2797.getPowerLevel() : "§7OFFLINE";
        context.method_51433(this.field_22793, "● " + statusText.replace("§", ""), x + 8, y + GUI_HEIGHT - 24, 0xFFD4A855, false);

        // === RIGHT PANEL ===
        int rx = x + 136;

        // Outside temperature
        drawSectionLabel(context, "OUTSIDE TEMPERATURE", rx, y + 22);
        context.method_25294(rx, y + 30, rx + 118, y + 50, 0xFF0F0C08);
        context.method_25294(rx, y + 30, rx + 118, y + 31, 0xFF2A1E10);
        context.method_25294(rx, y + 30, rx + 119, y + 50, 0xFF2A1E10);

        int tempColor = getTempColor();
        String tempStr = (field_2797.getOutsideTemp() >= 0 ? "+" : "") + field_2797.getOutsideTemp() + "°C";
        context.method_51433(this.field_22793, tempStr, rx + 4, y + 36, tempColor, false);
        String zoneStr = HEAT_ZONE_NAMES[field_2797.getHeatZone()];
        context.method_51433(this.field_22793, "◈ " + zoneStr, rx + 60, y + 36, tempColor, false);

        // Power level label
        drawSectionLabel(context, "POWER LEVEL", rx, y + 52);

        // Boost button state
        boolean boostUnlocked = field_2797.isBoostUnlocked();
        // (button text will show locked/unlocked state)

        // Heat zones section
        drawSectionLabel(context, "HEAT ZONE", rx, y + 128);
        drawHeatMeter(context, rx, y + 137);

        // Overload bar
        drawSectionLabel(context, "OVERDRIVE OVERLOAD", rx, y + 163);
        drawOverloadBar(context, rx, y + 171);

        // Coal supply
        drawSectionLabel(context, "COAL SUPPLY", rx, y + 183);
        // Coal slot background
        context.method_25294(rx, y + 191, rx + 20, y + 211, 0xFF0F0C08);
        context.method_25294(rx, y + 191, rx + 20, y + 192, 0xFF6A5030);
        context.method_25294(rx, y + 191, rx + 1, y + 211, 0xFF6A5030);
        context.method_25294(rx + 19, y + 191, rx + 20, y + 211, 0xFF2A1A08);
        context.method_25294(rx, y + 210, rx + 20, y + 211, 0xFF2A1A08);

        // Coal info
        int coal = field_2797.getCoalCount();
        int mins = field_2797.getMinutesOfCoalLeft();
        context.method_51433(this.field_22793, coal + "/64", rx + 24, y + 193, 0xFFD4A855, false);
        context.method_25294(rx + 24, y + 202, rx + 118, y + 208, 0xFF0F0C08);
        int barWidth = (int)((coal / 64.0f) * 94);
        if (barWidth > 0) {
            context.method_25294(rx + 24, y + 202, rx + 24 + barWidth, y + 208, 0xFFFF8800);
        }
        context.method_51433(this.field_22793, "~" + mins + " min left", rx + 24, y + 210, 0xFF5A4030, false);

        // Radius section
        drawSectionLabel(context, "HEAT RADIUS", rx, y + 217);
        drawRadiusPips(context, rx, y + 225);

        // Bottom info row
        context.method_25294(rx, y + GUI_HEIGHT - 22, rx + 118, y + GUI_HEIGHT - 2, 0xFF0F0C08);
        context.method_25294(rx, y + GUI_HEIGHT - 23, rx + 118, y + GUI_HEIGHT - 22, 0xFF2A1E10);
        String powerStr = "PWR: " + field_2797.getPowerLevel();
        String overStr = "OVR: " + field_2797.getOverloadPercent() + "%";
        context.method_51433(this.field_22793, powerStr, rx + 4, y + GUI_HEIGHT - 16, 0xFFD4A855, false);
        context.method_51433(this.field_22793, overStr, rx + 60, y + GUI_HEIGHT - 16, 0xFFFF6644, false);
    }

    private void drawSectionLabel(class_332 context, String label, int x, int y) {
        context.method_51433(this.field_22793, label, x, y, 0xFF5A4030, false);
        context.method_25294(x, y + 8, x + 118, y + 9, 0xFF2A1E10);
    }

    private void drawHeatMeter(class_332 context, int x, int y) {
        int currentZone = field_2797.getHeatZone();
        int[] heights = {14, 12, 10, 8, 6, 4};
        int[] colors = {0xFFCC2200, 0xFFCC8800, 0xFF2288CC, 0xFF0044CC, 0xFF001888, 0xFF440088};

        for (int i = 0; i < 6; i++) {
            int bx = x + i * 20;
            int bh = heights[i];
            int color = colors[i];
            boolean active = (i + 1) == currentZone;
            int finalColor = active ? color : (color & 0x00FFFFFF | 0x44000000);
            context.method_25294(bx, y + (14 - bh), bx + 18, y + 14, finalColor);
            if (active) {
                context.method_25294(bx, y + (14 - bh), bx + 18, y + (15 - bh), 0xFFFFFFFF);
            }
        }
    }

    private void drawOverloadBar(class_332 context, int x, int y) {
        int pct = field_2797.getOverloadPercent();
        context.method_25294(x, y, x + 118, y + 8, 0xFF0F0C08);
        context.method_25294(x, y, x + 118, y + 1, 0xFF2A1E10);

        int fillWidth = (int)((pct / 100.0f) * 116);
        if (fillWidth > 0) {
            int color = pct > 75 ? 0xFFFF0000 : pct > 50 ? 0xFFFF4400 : 0xFFFF8800;
            context.method_25294(x + 1, y + 1, x + 1 + fillWidth, y + 7, color);
        }

        // Danger zone
        context.method_25294(x + 95, y, x + 96, y + 8, 0x88FF0000);

        context.method_51433(this.field_22793, pct + "%", x + 100, y, 0xFFFF6644, false);
    }

    private void drawRadiusPips(class_332 context, int x, int y) {
        int[] radii = {30, 45, 65, 100};
        int currentRadius = field_2797.getRadiusLevel();
        for (int i = 0; i < 4; i++) {
            int px = x + i * 30;
            boolean active = (i + 1) <= currentRadius;
            context.method_25294(px, y, px + 28, y + 6,
                active ? 0xFFD4A855 : 0xFF0F0C08);
            context.method_25294(px, y, px + 28, y + 1, active ? 0xFFFFCC44 : 0xFF2A1E10);
        }
        context.method_51433(this.field_22793, "LVL " + currentRadius + " · " +
            (currentRadius > 0 && currentRadius <= 4 ? new int[]{30, 45, 65, 100}[currentRadius - 1] : 0) + " blocks",
            x, y + 8, 0xFF7A6040, false);
    }

    private int getTempColor() {
        return switch (field_2797.getHeatZone()) {
            case 1 -> 0xFFFF4422;
            case 2 -> 0xFFFFCC22;
            case 3 -> 0xFF44AAFF;
            case 4 -> 0xFF4488FF;
            case 5 -> 0xFF2255CC;
            case 6 -> 0xFFAA44FF;
            default -> 0xFFFFFFFF;
        };
    }

    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        // Suppress default title rendering
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);
        super.method_25394(context, mouseX, mouseY, delta);
        this.method_2380(context, mouseX, mouseY);
    }
}
