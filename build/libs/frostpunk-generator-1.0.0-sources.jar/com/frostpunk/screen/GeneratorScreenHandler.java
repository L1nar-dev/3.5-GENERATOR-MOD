package com.frostpunk.screen;

import com.frostpunk.FrostpunkMod;
import com.frostpunk.block.ControlPanelBlockEntity;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public class GeneratorScreenHandler extends class_1703 {

    private final ControlPanelBlockEntity blockEntity;
    private final class_1277 coalInventory;

    public record SyncData(class_2338 pos) {
        public static final class_9139<class_9129, SyncData> PACKET_CODEC =
            class_9139.method_56434(class_2338.field_48404, SyncData::pos, SyncData::new);
    }

    public GeneratorScreenHandler(int syncId, class_1661 playerInventory, SyncData data) {
        this(syncId, playerInventory,
            (ControlPanelBlockEntity) playerInventory.field_7546.method_37908().method_8321(data.pos()));
    }

    public GeneratorScreenHandler(int syncId, class_1661 playerInventory, ControlPanelBlockEntity blockEntity) {
        super(FrostpunkMod.GENERATOR_SCREEN_HANDLER, syncId);
        this.blockEntity = blockEntity;
        this.coalInventory = blockEntity != null ? blockEntity.getCoalInventory() : new class_1277(1);

        this.method_7621(new class_1735(coalInventory, 0, 26, 145) {
            @Override
            public boolean method_7680(class_1799 stack) {
                return stack.method_31574(class_1802.field_8713) || stack.method_31574(class_1802.field_8665);
            }
        });

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                this.method_7621(new class_1735(playerInventory, col + row * 9 + 9, 8 + col * 18, 174 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            this.method_7621(new class_1735(playerInventory, col, 8 + col * 18, 232));
        }
    }

    public ControlPanelBlockEntity getBlockEntity() { return blockEntity; }

    @Override
    public class_1799 method_7601(class_1657 player, int index) {
        class_1799 newStack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(index);
        if (slot.method_7681()) {
            class_1799 originalStack = slot.method_7677();
            newStack = originalStack.method_7972();
            if (index < 1) {
                if (!this.method_7616(originalStack, 1, this.field_7761.size(), true)) return class_1799.field_8037;
            } else {
                if (!this.method_7616(originalStack, 0, 1, false)) return class_1799.field_8037;
            }
            if (originalStack.method_7960()) slot.method_53512(class_1799.field_8037);
            else slot.method_7668();
        }
        return newStack;
    }

    @Override
    public boolean method_7597(class_1657 player) { return blockEntity != null; }

    public int getPowerLevel() { return blockEntity != null ? blockEntity.getPowerLevel() : 1; }
    public int getRadiusLevel() { return blockEntity != null ? blockEntity.getRadiusLevel() : 1; }
    public boolean isBoostUnlocked() { return blockEntity != null && blockEntity.isBoostUnlocked(); }
    public boolean isBoostActive() { return blockEntity != null && blockEntity.isBoostActive(); }
    public int getOverloadPercent() { return blockEntity != null ? blockEntity.getOverloadPercent() : 0; }
    public boolean isBroken() { return blockEntity != null && blockEntity.isBroken(); }
    public boolean isRunning() { return blockEntity != null && blockEntity.isRunning(); }
    public int getOutsideTemp() { return blockEntity != null ? blockEntity.getOutsideTemp() : -10; }
    public int getHeatZone() { return blockEntity != null ? blockEntity.getHeatZone() : 6; }
    public int getCoalCount() { return blockEntity != null ? blockEntity.getCoalCount() : 0; }
    public int getMinutesOfCoalLeft() { return blockEntity != null ? blockEntity.getMinutesOfCoalLeft() : 0; }
}
