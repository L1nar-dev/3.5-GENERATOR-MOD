package com.frostpunk;

import com.frostpunk.network.ModPackets;
import com.frostpunk.screen.GeneratorScreen;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_3929;

public class FrostpunkModClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        class_3929.method_17542(FrostpunkMod.GENERATOR_SCREEN_HANDLER, GeneratorScreen::new);
        ModPackets.registerClient();
    }
}
