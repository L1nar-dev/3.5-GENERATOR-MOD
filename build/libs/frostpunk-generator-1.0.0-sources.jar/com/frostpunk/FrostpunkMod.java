package com.frostpunk;

import com.frostpunk.block.ModBlocks;
import com.frostpunk.block.ModBlockEntities;
import com.frostpunk.command.GeneratorCommands;
import com.frostpunk.screen.GeneratorScreenHandler;
import com.frostpunk.network.ModPackets;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FrostpunkMod implements ModInitializer {

    public static final String MOD_ID = "frostpunk_generator";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static class_3917<GeneratorScreenHandler> GENERATOR_SCREEN_HANDLER;

    @Override
    public void onInitialize() {
        LOGGER.info("Frostpunk Generator initializing...");
        ModBlocks.register();
        ModBlockEntities.register();
        ModPackets.registerServer();
        GeneratorCommands.register();
        GENERATOR_SCREEN_HANDLER = class_2378.method_10230(
            class_7923.field_41187,
            class_2960.method_60655(MOD_ID, "generator"),
            new ExtendedScreenHandlerType<>(
                GeneratorScreenHandler::new,
                GeneratorScreenHandler.SyncData.PACKET_CODEC
            )
        );
        LOGGER.info("Frostpunk Generator ready. The city must survive.");
    }
}
