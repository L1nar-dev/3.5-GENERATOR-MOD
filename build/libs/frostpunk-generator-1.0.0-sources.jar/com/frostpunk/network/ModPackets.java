package com.frostpunk.network;

import com.frostpunk.FrostpunkMod;
import com.frostpunk.block.ControlPanelBlockEntity;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class ModPackets {

    // Packet IDs
    public static final class_8710.class_9154<SetPowerPacket> SET_POWER_ID =
        new class_8710.class_9154<>(class_2960.method_60655(FrostpunkMod.MOD_ID, "set_power"));
    public static final class_8710.class_9154<SetRadiusPacket> SET_RADIUS_ID =
        new class_8710.class_9154<>(class_2960.method_60655(FrostpunkMod.MOD_ID, "set_radius"));
    public static final class_8710.class_9154<ToggleBoostPacket> TOGGLE_BOOST_ID =
        new class_8710.class_9154<>(class_2960.method_60655(FrostpunkMod.MOD_ID, "toggle_boost"));

    // Packet records
    public record SetPowerPacket(class_2338 pos, int level) implements class_8710 {
        public static final class_9139<class_9129, SetPowerPacket> CODEC =
            class_9139.method_56435(class_2338.field_48404, SetPowerPacket::pos,
                class_9135.field_49675, SetPowerPacket::level, SetPowerPacket::new);
        @Override public class_9154<? extends class_8710> method_56479() { return SET_POWER_ID; }
    }

    public record SetRadiusPacket(class_2338 pos, int level) implements class_8710 {
        public static final class_9139<class_9129, SetRadiusPacket> CODEC =
            class_9139.method_56435(class_2338.field_48404, SetRadiusPacket::pos,
                class_9135.field_49675, SetRadiusPacket::level, SetRadiusPacket::new);
        @Override public class_9154<? extends class_8710> method_56479() { return SET_RADIUS_ID; }
    }

    public record ToggleBoostPacket(class_2338 pos) implements class_8710 {
        public static final class_9139<class_9129, ToggleBoostPacket> CODEC =
            class_9139.method_56434(class_2338.field_48404, ToggleBoostPacket::pos, ToggleBoostPacket::new);
        @Override public class_9154<? extends class_8710> method_56479() { return TOGGLE_BOOST_ID; }
    }

    // Server registration
    public static void registerServer() {
        PayloadTypeRegistry.playC2S().register(SET_POWER_ID, SetPowerPacket.CODEC);
        PayloadTypeRegistry.playC2S().register(SET_RADIUS_ID, SetRadiusPacket.CODEC);
        PayloadTypeRegistry.playC2S().register(TOGGLE_BOOST_ID, ToggleBoostPacket.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(SET_POWER_ID, (payload, context) -> {
            class_3222 player = context.player();
            context.server().execute(() -> {
                class_2586 be = player.method_37908().method_8321(payload.pos());
                if (be instanceof ControlPanelBlockEntity panel) {
                    panel.setPowerLevel(payload.level(), player);
                }
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(SET_RADIUS_ID, (payload, context) -> {
            class_3222 player = context.player();
            context.server().execute(() -> {
                class_2586 be = player.method_37908().method_8321(payload.pos());
                if (be instanceof ControlPanelBlockEntity panel) {
                    panel.setRadiusLevel(payload.level(), player);
                }
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(TOGGLE_BOOST_ID, (payload, context) -> {
            class_3222 player = context.player();
            context.server().execute(() -> {
                class_2586 be = player.method_37908().method_8321(payload.pos());
                if (be instanceof ControlPanelBlockEntity panel) {
                    panel.setBoostActive(!panel.isBoostActive(), player);
                }
            });
        });
    }

    // Client registration
    public static void registerClient() {
        PayloadTypeRegistry.playC2S().register(SET_POWER_ID, SetPowerPacket.CODEC);
        PayloadTypeRegistry.playC2S().register(SET_RADIUS_ID, SetRadiusPacket.CODEC);
        PayloadTypeRegistry.playC2S().register(TOGGLE_BOOST_ID, ToggleBoostPacket.CODEC);
    }

    // Client send helpers — need pos from open screen
    public static void sendSetPower(int level) {
        // Handled in GeneratorScreen via handler
    }

    public static void sendSetRadius(int level) {
        // Handled in GeneratorScreen via handler
    }

    public static void sendToggleBoost() {
        // Handled in GeneratorScreen via handler
    }
}
