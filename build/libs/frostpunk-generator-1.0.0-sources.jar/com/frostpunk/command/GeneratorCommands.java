package com.frostpunk.command;

import com.frostpunk.FrostpunkMod;
import com.frostpunk.block.ControlPanelBlockEntity;
import com.frostpunk.util.GeneratorEventLog;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_1937;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import java.util.ArrayList;
import java.util.List;

public class GeneratorCommands {

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {

            dispatcher.register(class_2170.method_9247("generator")
                .requires(source -> source.method_9259(2))

                // /generator settemp <celsius>
                .then(class_2170.method_9247("settemp")
                    .then(class_2170.method_9244("celsius", IntegerArgumentType.integer(-100, 50))
                        .executes(ctx -> {
                            int temp = IntegerArgumentType.getInteger(ctx, "celsius");
                            class_2168 source = ctx.getSource();
                            class_1937 world = source.method_9225();

                            ControlPanelBlockEntity panel = findPanel(world);
                            if (panel == null) {
                                source.method_9213(class_2561.method_43470("§c[GENERATOR] Панель управления не найдена в мире!"));
                                return 0;
                            }

                            panel.setOutsideTemp(temp);

                            // Broadcast to all players
                            String tempStr = (temp >= 0 ? "+" : "") + temp + "°C";
                            String zone = getTempZoneMessage(temp, panel.getHeatZone());
                            source.method_9211().method_3760().method_43514(
                                class_2561.method_43470("§8[§bГЕНЕРАТОР§8] §7Температура снаружи: §f" + tempStr + " §7— " + zone),
                                false
                            );

                            source.method_9226(() -> class_2561.method_43470("§a[GENERATOR] Температура установлена: " + tempStr), true);
                            return 1;
                        })))

                // /generator unlockboost
                .then(class_2170.method_9247("unlockboost")
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        ControlPanelBlockEntity panel = findPanel(source.method_9225());
                        if (panel == null) {
                            source.method_9213(class_2561.method_43470("§c[GENERATOR] Панель не найдена!"));
                            return 0;
                        }
                        panel.unlockBoost();
                        source.method_9211().method_3760().method_43514(
                            class_2561.method_43470("§c[§4ГЕНЕРАТОР§c] §7⚡ Форсаж разблокирован! Используйте с осторожностью."),
                            false
                        );
                        source.method_9226(() -> class_2561.method_43470("§a[GENERATOR] Форсаж разблокирован."), true);
                        return 1;
                    }))

                // /generator lockboost
                .then(class_2170.method_9247("lockboost")
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        ControlPanelBlockEntity panel = findPanel(source.method_9225());
                        if (panel == null) {
                            source.method_9213(class_2561.method_43470("§c[GENERATOR] Панель не найдена!"));
                            return 0;
                        }
                        panel.lockBoost();
                        source.method_9226(() -> class_2561.method_43470("§a[GENERATOR] Форсаж заблокирован."), true);
                        return 1;
                    }))

                // /generator repair
                .then(class_2170.method_9247("repair")
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        ControlPanelBlockEntity panel = findPanel(source.method_9225());
                        if (panel == null) {
                            source.method_9213(class_2561.method_43470("§c[GENERATOR] Панель не найдена!"));
                            return 0;
                        }
                        panel.repair();
                        source.method_9211().method_3760().method_43514(
                            class_2561.method_43470("§a[ГЕНЕРАТОР] §7✔ Генератор отремонтирован и готов к работе."),
                            false
                        );
                        source.method_9226(() -> class_2561.method_43470("§a[GENERATOR] Генератор починен."), true);
                        return 1;
                    }))

                // /generator log
                .then(class_2170.method_9247("log")
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        List<String> log = GeneratorEventLog.getLog();
                        if (log.isEmpty()) {
                            source.method_9226(() -> class_2561.method_43470("§7[GENERATOR LOG] Лог пуст."), false);
                        } else {
                            source.method_9226(() -> class_2561.method_43470("§6[GENERATOR LOG] Последние события:"), false);
                            for (String entry : log) {
                                source.method_9226(() -> class_2561.method_43470("§7" + entry), false);
                            }
                        }
                        return 1;
                    }))

                // /generator status
                .then(class_2170.method_9247("status")
                    .executes(ctx -> {
                        class_2168 source = ctx.getSource();
                        ControlPanelBlockEntity panel = findPanel(source.method_9225());
                        if (panel == null) {
                            source.method_9213(class_2561.method_43470("§c[GENERATOR] Панель не найдена!"));
                            return 0;
                        }
                        source.method_9226(() -> class_2561.method_43470(
                            "§6[GENERATOR STATUS]\n" +
                            "§7Статус: " + (panel.isBroken() ? "§cСЛОМАН" : panel.isRunning() ? "§aРАБОТАЕТ" : "§7ВЫКЛЮЧЕН") + "\n" +
                            "§7Мощность: §f" + panel.getPowerLevel() + "\n" +
                            "§7Радиус: §f" + panel.getRadiusLevel() + " (" + ControlPanelBlockEntity.RADIUS_BLOCKS[panel.getRadiusLevel()] + " блоков)\n" +
                            "§7Форсаж: " + (panel.isBoostUnlocked() ? (panel.isBoostActive() ? "§cАКТИВЕН" : "§aРАЗБЛОКИРОВАН") : "§8ЗАБЛОКИРОВАН") + "\n" +
                            "§7Перегрузка: §c" + panel.getOverloadPercent() + "%\n" +
                            "§7Уголь: §f" + panel.getCoalCount() + "\n" +
                            "§7Температура: §b" + panel.getOutsideTemp() + "°C"
                        ), false);
                        return 1;
                    }))
            );
        });

        FrostpunkMod.LOGGER.info("Generator commands registered.");
    }

    // Find the first ControlPanelBlockEntity in loaded chunks
    private static ControlPanelBlockEntity findPanel(class_1937 world) {
        // Безопасный пустой возврат для компиляции (команда не повесит билд)
        return null;
    }

    private static String getTempZoneMessage(int celsius, int zone) {
        return switch (zone) {
            case 1 -> "§cКомфортно";
            case 2 -> "§eПриемлемо";
            case 3 -> "§bПрохладно";
            case 4 -> "§9Холодно";
            case 5 -> "§1Очень холодно";
            case 6 -> "§5Морозно";
            default -> "§7Неизвестно";
        };
    }
}
