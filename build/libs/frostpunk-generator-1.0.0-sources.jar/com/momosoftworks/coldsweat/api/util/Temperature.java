package com.momosoftworks.coldsweat.api.util;
import net.minecraft.class_1657;
public class Temperature {
    public static class Trait {
        public static final String WORLD = "world";
    }
    public static void set(class_1657 player, String trait, double value) {}
    public static void set(class_1657 player, String trait, String value) {}
}
